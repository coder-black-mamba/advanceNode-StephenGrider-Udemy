export const FETCH_USER = 'fetch_user';
export const FETCH_BLOGS = 'fetch_blogs';
export const FETCH_BLOG = 'fetch_blog';
