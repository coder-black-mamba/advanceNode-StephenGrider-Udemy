export default [
  { label: 'Blog Title', name: 'title' },
  { label: 'Content', name: 'content' }
];
